THIS NITRO SNIPER CAN GET YOU BANNED. 

-USE ON ALTERNATE ACCOUNT		

thats it lol.


add me on discord for help	

(khakerman#8008)